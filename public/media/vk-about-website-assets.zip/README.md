# VK AND COMPANY — About-page image pack

## Add to your project
Merge the contents of this ZIP into the existing Next.js project root (the folder containing package.json). Keep all existing files and folders; do not replace or delete the existing public directory.

The images go in public/images/about/. The visual reference goes in design-references/. It is for implementation reference only and must not be rendered as the page itself.

Open CODEX-PROMPT.txt and paste its contents into Codex after the files have been added. This pack does not contain a completed site implementation; the prompt instructs Codex to update the existing About-page section.

## Assets
- logistics-network.webp: 642 × 595 pixels; main logistics illustration.
- customer-journey.webp: 277 × 215 pixels; parcel preparation.
- service-confirmation.webp: 277 × 216 pixels; courier truck.
- customer-support.webp: 277 × 218 pixels; support representative.

These visuals were cropped from the approved assistant-generated mockup and encoded as WebP. They are not separate high-resolution originals, and no upscaling was used. The smaller images are intended for thumbnails, not large hero backgrounds. Pixel dimensions and source crop coordinates are recorded in asset-manifest.json.

The source mockup is AI-generated illustrative artwork, not verified photography of the company’s premises, fleet, or staff. Logos rendered within the illustrations are part of that artwork; they must not replace the business’s actual approved logo asset.

The generated preview includes service slogans that were not established in the original page copy. The implementation prompt keeps the four-icon visual treatment but uses neutral labels instead of introducing unverified delivery or coverage promises.

Keep the three current paragraphs as real selectable HTML text. Recreate the section layout responsively; never use the entire reference image as the implemented webpage.
